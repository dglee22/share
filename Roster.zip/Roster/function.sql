delimiter %%
CREATE OR REPLACE FUNCTION get_team_colors(
	IN tid INT) RETURNS VARCHAR(100)
BEGIN
	DECLARE color_count INT DEFAULT 0;
	DECLARE color_name_t VARCHAR(10);
	DECLARE color_name_acc VARCHAR(50) DEFAULT '';
	
	SELECT COUNT(color_id) INTO color_count
		FROM team_color WHERE team_id=tid;
		
	FOR i IN 0..(color_count-1)
	DO
		SELECT color.name INTO color_name_t
			FROM team_color
			JOIN color ON team_color.color_id=color.id
			WHERE team_color.team_id = tid
			LIMIT 1 OFFSET i;
		set color_name_acc =  
			CONCAT(color_name_acc,', ', color_name_t);
	END FOR;
	RETURN trim(LEADING ', s' from color_name_acc);
END%%

delimiter ;