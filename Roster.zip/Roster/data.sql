SET foreign_key_checks = 0;

TRUNCATE color;
TRUNCATE player;
TRUNCATE sponsor;
TRUNCATE team;
TRUNCATE team_color;

INSERT INTO `color` (`id`, `name`) VALUES
	(1, 'blue'),
	(2, 'gold'),
	(3, 'red'),
	(4, 'white'),
	(5, 'dark gray');

INSERT INTO `sponsor` (`id`, `NAME`) VALUES
	(1, 'Albert\'s Photo'),
	(2, 'Things R Us'),
	(3, 'Better Boots');
	
INSERT INTO `team` (`id`, `NAME`, `sponsor_id`) VALUES
	(1, 'Thunderheads', 1),
	(2, 'Stratospheres', 2),
	(3, 'Typhoons', 3),
	(5, 'no_team', 1);

INSERT INTO `player` (`id`, `first_name`, `last_name`, `phone`, `average`, `team_id`) VALUES
	(1, 'Bill', 'Smith', '995-0987', 14, 1),
	(2, 'Cindy', 'Blau', '877-2377', 17, 1),
	(3, 'Anne', 'Kellehan', '271-3444', 12, 2),
	(4, 'Bill', 'Altmeter', '271-8850', 19, 2),
	(5, 'Andy', 'Power', '271-4401', 11, 1),
	(8, 'Mark', 'Johnson', '995-0906', 0, 2);

INSERT INTO `team_color` (`id`, `team_id`, `color_id`) VALUES
	(1, 1, 1),
	(2, 1, 2),
	(3, 2, 3),
	(4, 2, 4),
	(6, 3, 5);
	
SET foreign_key_checks=1;