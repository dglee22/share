delimiter %%
CREATE or replace PROCEDURE insert_player_to_team(
	IN team_name VARCHAR(20),
	IN player_firstname VARCHAR(10),
	IN player_lastname VARCHAR(10),
	IN player_phone VARCHAR(15))
BEGIN
	DECLARE tid INT DEFAULT 0;
	SELECT id INTO tid FROM team WHERE NAME=team_name;
	if tid IS NOT NULL then
		INSERT INTO player(first_name, last_name, phone, team_id)
			VALUES(player_firstname, player_lastname,
				player_phone,tid);
	end if;
END%%

CREATE or replace PROCEDURE delete_team(IN tid INT)
BEGIN
	-- player 중,
	-- 삭제하려는 팀에 소속된 player 명수 찾기
	DECLARE n INT DEFAULT 0;
	DECLARE m INT DEFAULT 0;
	
	SELECT COUNT(id) INTO n
		FROM player WHERE team_id=tid;
	-- player 마다, 팀 소속을 no_team으로 변경.
	FOR i IN 0..n
	do
		SELECT id INTO m FROM player
			WHERE team_id=tid
			LIMIT 1 OFFSET i;
		UPDATE player SET team_id=4 WHERE id=m;
	END FOR;
	-- team 삭제
	DELETE FROM team WHERE id=tid;
END%%

CREATE or replace PROCEDURE set_team_color(
	IN tid INT, IN color_name VARCHAR(10))
BEGIN
	DECLARE n INT DEFAULT 0;
	-- team_color 테이블에서
	-- 해당 팀의 컬러 정보  모두 삭제
	DELETE FROM team_color WHERE team_id=tid;
	
	-- color 테이블에, 설정하고자 하는 색이 있는지 확인.
	SELECT id INTO n FROM color WHERE NAME=color_name;
	-- 없다면, color 테이블에 색 추가. 추가된 id 가져오기
	if n IS NULL then
		INSERT INTO color(NAME) VALUES(color_name);
		SELECT LAST_INSERT_ID() INTO n;
	END if;
	-- 색에 맞는 id값을 n에 받아옴.
	-- team_color 테이블에 팀의 색 설정.
	INSERT INTO team_color(team_id, color_id)
		VALUES(tid,n);
END%%

CREATE OR REPLACE PROCEDURE add_team_color(
	IN tid INT, IN color_name VARCHAR(10))
BEGIN
	-- color 테이블에, 설정하고자 하는 색이 있는지 확인.
	-- 없다면, color 테이블에 색 추가. 추가된 id 가져오기	-- 색에 맞는 id값을 n에 받아옴.
	-- team_color 테이블에 팀의 색 추가 설정.
END%%

CREATE OR REPLACE TRIGGER warn_lower_avg
	BEFORE UPDATE ON player FOR EACH row
BEGIN
	DECLARE old_avg INT DEFAULT 0;
	SELECT average INTO old_avg FROM player
		WHERE id = NEW.id;
	if old_avg<NEW.average then
		INSERT INTO player_info(note)
			VALUES('lower player average');
	END if;
END%%

delimiter ;