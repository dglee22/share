CREATE OR REPLACE table color(
	id INT
		NOT NULL AUTO_INCREMENT PRIMARY KEY,
	name VARCHAR(10) NOT null
);
CREATE OR REPLACE table sponsor(
	id INT
		NOT NULL AUTO_INCREMENT PRIMARY KEY,
	NAME VARCHAR(20) NOT NULL
);
CREATE OR REPLACE table team(
	id INT
		NOT NULL AUTO_INCREMENT PRIMARY KEY,
	NAME VARCHAR(20) NOT NULL,
	sponsor_id INT,
	FOREIGN KEY(sponsor_id)
		REFERENCES sponsor(id) ON DELETE SET null
);
CREATE OR REPLACE table player(
	id INT
		NOT NULL AUTO_INCREMENT PRIMARY KEY,
	first_name VARCHAR(20) NOT NULL,
	last_name VARCHAR(20) NOT NULL,
	phone VARCHAR(15),
	average int	DEFAULT 0,
	team_id INT,
	FOREIGN KEY(team_id)
		REFERENCES team(id) ON DELETE SET null
);
CREATE OR REPLACE table team_color(
	id INT
		NOT NULL AUTO_INCREMENT PRIMARY KEY,
	team_id INT NOT NULL,
	color_id INT NOT NULL,
	FOREIGN KEY(team_id)
		REFERENCES team(id) ON DELETE cascade,
	FOREIGN KEY(color_id)
		REFERENCES color(id)
);