SELECT concat(player.first_name, ' ', player.last_name) AS player,
	player.phone, player.average,
	team.NAME AS team, get_team_colors(player.team_id),
	sponsor.name
	FROM player
	JOIN team ON player.team_id = team.id
	JOIN sponsor ON team.sponsor_id = sponsor.id;

SELECT sponsor_id, count(id)
	FROM team
	GROUP BY sponsor_id;
	
SELECT team_id, COUNT(color_id)
	FROM team_color
	GROUP BY team_id;
	
SELECT team_id, COUNT(id)
	FROM player
	GROUP BY team_id;